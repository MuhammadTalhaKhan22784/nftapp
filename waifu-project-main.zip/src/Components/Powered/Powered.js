import React from "react";
import "./Powered.css";
import img1 from "../../Assets/Powered By/powered (1).png";
import img2 from "../../Assets/Powered By/powered (2).png";
import img3 from "../../Assets/Powered By/powered (3).png";
import img4 from "../../Assets/Powered By/powered (4).png";
import img5 from "../../Assets/Powered By/powered (5).png";
import img6 from "../../Assets/Powered By/powered (6).png";
import img7 from "../../Assets/Powered By/powered (7).png";
import img8 from "../../Assets/Powered By/powered (8).png";
import img9 from "../../Assets/Powered By/powered (9).png";
import img10 from "../../Assets/Powered By/powered (10).png";
import img11 from "../../Assets/Powered By/powered (11).png";
import img12 from "../../Assets/Powered By/powered (12).png";
import img13 from "../../Assets/Powered By/powered (13).png";
import img14 from "../../Assets/Powered By/powered (14).png";
import img15 from "../../Assets/Powered By/powered (15).png";
import img16 from "../../Assets/Powered By/powered (16).png";
import img17 from "../../Assets/Powered By/powered (17).png";
import img18 from "../../Assets/Powered By/powered (18).png";
import img19 from "../../Assets/Powered By/powered (19).png";
function Powered() {
  return (
    <div className="powered">
      <h1 data-aos="fade-up" data-aos-once='true' >Powered By</h1>
      <div data-aos="fade-up" data-aos-delay="300" data-aos-once='true' className="power_grid">
        <img src={img1} alt="" className="power_img" />
        <img src={img2} alt="" className="power_img" />
        <img src={img3} alt="" className="power_img" />
        <img src={img4} alt="" className="power_img" />
        <img src={img5} alt="" className="power_img" />
        <img src={img6} alt="" className="power_img" />
        <img src={img7} alt="" className="power_img" />
        <img src={img8} alt="" className="power_img" />
        <img src={img9} alt="" className="power_img" />
        <img src={img10} alt="" className="power_img" />
        <img src={img11} alt="" className="power_img" />
        <img src={img12} alt="" className="power_img" />
        <img src={img13} alt="" className="power_img" />
        <img src={img14} alt="" className="power_img" />
        <img src={img15} alt="" className="power_img" />
        <img src={img16} alt="" className="power_img" />
        <img src={img17} alt="" className="power_img" />
        <img src={img18} alt="" className="power_img" />
        <img src={img19} alt="" className="power_img" />
      </div>
    </div>
  );
}

export default Powered;
