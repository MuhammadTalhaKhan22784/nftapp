

// prefer default export if available
const preferDefault = m => (m && m.default) || m


exports.components = {
  "component---cache-dev-404-page-js": (preferDefault(require("G:\\React\\Raja Client\\waifu-project-main\\.cache\\dev-404-page.js"))),
  "component---src-pages-component-js": (preferDefault(require("G:\\React\\Raja Client\\waifu-project-main\\src\\pages\\component.js"))),
  "component---src-pages-index-js": (preferDefault(require("G:\\React\\Raja Client\\waifu-project-main\\src\\pages\\index.js")))
}

