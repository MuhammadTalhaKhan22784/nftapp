"use strict";

require("gatsby-legacy-polyfills");

if (process.env.NODE_ENV === `development`) {
  require(`event-source-polyfill`);
}