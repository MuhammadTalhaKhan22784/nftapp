"use strict";

exports.__esModule = true;
exports.a = void 0;
// Dummy file to work around a webpack hot reloading bug.
const a = 1;
exports.a = a;